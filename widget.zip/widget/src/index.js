const window = require('window');

const Plugin = require('../../plugin/Plugin');
const Widget = require('./Widget');

window.VLibras.Plugin = Plugin;
window.VLibras.Widget = Widget;
